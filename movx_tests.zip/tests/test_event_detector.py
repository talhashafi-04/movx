"""TC-07: AH / BR frame error of the event TCN on held-out bowlers.

Reads the per-clip predictions saved by `python src/event_tcn.py eval --csv outputs/tcn_eval.csv`
and checks them against data/labels.csv. It does not retrain or re-run the model;
test_rerun_matches_saved_csv below does that when PyTorch is installed.
"""
import statistics
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import LABELS, ROOT, TCN_EVAL, read_csv  # noqa: E402

MAX_ERR = 3          # frames; 3 frames = 12.5 ms at 240 fps (SC3 asks for a median <= 3)


class EventDetector(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pred = read_csv(TCN_EVAL)
        cls.labels = {r["clip"]: r for r in read_csv(LABELS)}

    def test_only_held_out_bowlers_are_evaluated(self):
        train_players = {r["player"] for r in self.labels.values() if r["split"] == "train"}
        for r in self.pred:
            self.assertIn(r["split"], {"val", "test"})
            self.assertNotIn(r["player"], train_players, r["clip"])
            self.assertEqual(self.labels[r["clip"]]["split"], r["split"], r["clip"])

    def test_saved_labels_and_errors_are_consistent(self):
        for r in self.pred:
            lab = self.labels[r["clip"]]
            self.assertEqual(int(r["ah"]), int(lab["ah_1based"]), r["clip"])
            self.assertEqual(int(r["br"]), int(lab["br_1based"]), r["clip"])
            self.assertEqual(int(r["err_ah"]), int(r["pred_ah"]) - int(r["ah"]), r["clip"])
            self.assertEqual(int(r["err_br"]), int(r["pred_br"]) - int(r["br"]), r["clip"])

    def test_every_held_out_clip_is_evaluated(self):
        held_out = {c for c, r in self.labels.items() if r["split"] in {"val", "test"}}
        self.assertEqual({r["clip"] for r in self.pred}, held_out)

    def test_all_errors_within_three_frames(self):
        for key in ("err_ah", "err_br"):
            errs = [abs(int(r[key])) for r in self.pred]
            self.assertLessEqual(max(errs), MAX_ERR, key)
            self.assertLessEqual(statistics.median(errs), MAX_ERR, key)

    def test_rerun_matches_saved_csv(self):
        """Re-run the ensemble and compare with the saved predictions (needs torch)."""
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("PyTorch not installed")
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "tcn_eval_rerun.csv"
            subprocess.run([sys.executable, str(ROOT / "src" / "event_tcn.py"), "eval",
                            "--csv", str(out)], cwd=ROOT, check=True)
            new = {r["clip"]: r for r in read_csv(out)}
        for r in self.pred:
            self.assertEqual(new[r["clip"]]["pred_ah"], r["pred_ah"], r["clip"])
            self.assertEqual(new[r["clip"]]["pred_br"], r["pred_br"], r["clip"])


if __name__ == "__main__":
    unittest.main()
