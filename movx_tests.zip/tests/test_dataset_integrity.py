"""TC-01, TC-02, TC-03: data integrity of the trimmed clips and data/labels.csv.

Run from the repository root:
    python -m unittest discover -s tests -v
(pytest also works: pytest tests)
"""
import sys
import unittest
from pathlib import Path

import cv2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import LABELS, TRIMMED, read_csv  # noqa: E402

SPLITS = {"train", "val", "test"}


class DatasetIntegrity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = read_csv(LABELS)

    def test_tc01_manifest_and_files_agree(self):
        """TC-01: every manifest row has a clip file, and every clip file is listed."""
        listed = {r["clip"] for r in self.rows}
        on_disk = {f"{p.parent.name}/{p.name}" for p in TRIMMED.glob("*/*.mp4")}
        self.assertGreater(len(listed), 0)
        self.assertEqual(sorted(listed - on_disk), [], "manifest rows with no clip file")
        self.assertEqual(sorted(on_disk - listed), [], "clip files missing from the manifest")
        self.assertEqual(len(listed), len(self.rows), "duplicate clip rows in the manifest")

    def test_tc02_clip_format_frame_counts_and_event_order(self):
        """TC-02: 1920x1080, frame count matches the manifest, AH < BR, both inside the clip."""
        for r in self.rows:
            with self.subTest(clip=r["clip"]):
                cap = cv2.VideoCapture(str(TRIMMED / r["clip"]))
                self.assertTrue(cap.isOpened(), "cannot open clip")
                width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                frames = 0
                while cap.grab():          # count by decoding, not by container metadata
                    frames += 1
                cap.release()
                self.assertEqual((width, height), (1920, 1080))
                self.assertEqual(frames, int(r["frame_count"]), "frame count differs from manifest")
                ah, br = int(r["ah_1based"]), int(r["br_1based"])
                self.assertLess(ah, br, "AH must come before BR")
                self.assertGreaterEqual(ah, 1)
                self.assertLessEqual(br, frames)
                self.assertEqual(int(r["span"]), br - ah, "span column differs from BR - AH")

    def test_tc03_no_bowler_in_more_than_one_split(self):
        """TC-03: split by bowler, so no player appears in two splits."""
        splits_of = {}
        for r in self.rows:
            self.assertIn(r["split"], SPLITS, r["clip"])
            splits_of.setdefault(r["player"], set()).add(r["split"])
        leaks = {p: sorted(s) for p, s in splits_of.items() if len(s) > 1}
        self.assertEqual(leaks, {}, "bowlers present in more than one split")
        self.assertEqual(len(splits_of), len({r["clip"].split("/")[0] for r in self.rows}))


if __name__ == "__main__":
    unittest.main()
