"""Shared paths and helpers for the BowlSense tests (standard library + OpenCV only)."""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LABELS = ROOT / "data" / "labels.csv"
TRIMMED = ROOT / "trimmed"
TCN_EVAL = ROOT / "outputs" / "tcn_eval.csv"


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))
